RAIZEN FF — LANDING CATALOG V4

Cambios:
- Se eliminó la skin del hero para evitar el espacio visual que no convencía.
- Título principal: VENTAS - RAIZEN FREE FIRE.
- Los títulos DIAMANTES, PASE BOOYAH y CAJAS EVOLUTIVAS son más grandes.
- Cada apartado tiene el botón "Comprar por WhatsApp".
- Se mantiene responsive para PC, tablet y celular.
- Se conserva el enfoque de catálogo/landing, con contacto por WhatsApp.
